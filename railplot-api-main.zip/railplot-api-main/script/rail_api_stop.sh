#!/bin/bash

# Define the port number where Flask is running
PORT=5010  # Replace this with the actual port number

# Find the process ID (PID) of the process using the port
PID=$(lsof -ti:$PORT)

# Check if the PID was found
if [ -z "$PID" ]; then
    echo "No process is running on port $PORT."
else
    # Kill the process
    kill -9 $PID
    echo "Process running on port $PORT (PID: $PID) has been stopped."
fi
