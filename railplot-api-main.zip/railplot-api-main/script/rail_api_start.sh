#!/bin/bash
cd /Users/girish/workspace/rail_data
echo "starting rail api ..."
python3 -m venv ./venv
source ./venv/bin/activate
pip install -r requirements.txt
nohup python app.py &