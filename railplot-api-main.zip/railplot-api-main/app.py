from flask import Flask, request, jsonify, send_file, send_from_directory
from collections import OrderedDict
from flask import Response
from flask_jwt_extended import create_access_token, JWTManager
import json
import pandas as pd
from flask_cors import CORS
import plotly.express as px
import plotly.io as pio
import plotly.graph_objects as go
import numpy as np
from datetime import datetime
import json
import logging
from logging.handlers import RotatingFileHandler
import traceback

from dto.api_response import ApiResponse
from conf.error_msg import ERR_MSG

from services.rail_data_prep import RailDataService
from utils.report_utils import ReportUtils
from conf.const import RailConst
app = Flask(__name__)
app.config["JWT_SECRET_KEY"] = 'hello'
CORS(app)
jwtM = JWTManager(app)

logger = logging.getLogger()

logFormatter = logging.Formatter('%(asctime)s [%(filename)s %(funcName)s %(lineno)d] %(message)s', datefmt='%m/%d/%Y %I:%M:%S %p')
fileHandler = RotatingFileHandler('logs/rail_log.log', backupCount=100, maxBytes=1024*1024)
fileHandler.setFormatter(logFormatter)
logger.addHandler(fileHandler)
logger.setLevel(logging.INFO)

report_file = 'data/report.json'
template_file = 'data/templates.json'
supported_sources = 'data/data_sources.json'
crew_file = 'data/crew.csv'

crew_df = pd.read_csv(crew_file)

@app.route('/', methods=['GET'])
def hello():
    logging.info(f"api working ...")
    return jsonify({
        "message": "api working!"
    }), 200

def get_additional_claims(id, name, email):
    additional_claims = {
        'id': str(id),
        'name': name,
        'email': email
    }
    return additional_claims

@app.route('/crew_details', methods=['GET'])
def crew_details():
    crew_cms_id = request.args.get('crew_id')
    crew_rows = crew_df[crew_df['cms_id'] == crew_cms_id]

    crew_details = {}
    print(f'crew row : {crew_rows}')
    if not crew_rows.empty:
        crew_row = crew_rows.iloc[0]  #
        crew_details = {
            'lp_cms_id': crew_row['cms_id'],
            'nominated_cli': crew_row['crew_nli'],
            'crew_name': crew_row['crew_name'],
            'designation': crew_row['crew_designation']
        }

    print(f'crew_details : {crew_details}')

    return jsonify(crew_details), 200

@app.route('/reports', methods=['GET'])
def reports():
    reportUtil = ReportUtils(report_file)
    report_data = reportUtil.get_report()
    #last_rep_id = reportUtil.get_report_last_id()

    #print(f'last_rep_id : {last_rep_id}')
    return jsonify(report_data), 200

@app.route('/templates', methods=['GET'])
def templates():
    #data =  None
    with open(template_file, "r", encoding="utf-8-sig") as file:
        data = json.load(file)  # Converts JSON to a Python dictionary

    return jsonify(data), 200

@app.route('/supported_data_sources', methods=['GET'])
def sources():
    #data =  None
    with open(supported_sources, "r", encoding="utf-8-sig") as file:
        data = json.load(file)  # Converts JSON to a Python dictionary

    return jsonify(data), 200

def ordered_jsonify(apiResponse):
    return Response(
        response=json.dumps(apiResponse.__dict__, indent=2),
        status=apiResponse.status,
        mimetype='application/json'
    )


@app.route('/metadata', methods=['GET'])
def metadata():
    apiResponse = ApiResponse(200, 'ok', None)
    try :
        template_id = request.args.get('template_id', type=int)
        data_src = request.args.get('data_src')
        download = request.args.get('download')
        templates_json = None
        with open(template_file, "r", encoding="utf-8-sig") as file:
            templates_json = json.load(file)  # Converts JSON to a Python dictionary

        one_template = next((template for template in templates_json["templates"] if template["id"] == template_id), None)
        if one_template :
            data_src_link = one_template.get(data_src)
            logging.info(f'data_src_link : {data_src_link}')

            if data_src_link :
                if download == str(1):
                    return send_from_directory(directory=".",path=data_src_link, as_attachment=True)
                else :
                    with open(data_src_link, "r", encoding="utf-8-sig") as file:
                        #apiResponse.data = json.load(file)
                        meta_df = pd.read_csv(file)
                        data = [
                            OrderedDict((col, row[col]) for col in meta_df.columns)
                            for _, row in meta_df.iterrows()
                        ]

                        apiResponse.data = data
            else:
                apiResponse.data = {
                    'message': f'Template with data_src {data_src} not found.'
                }
        else:
            apiResponse.data = {
                'message' : f'Template with id {template_id} not found.'
            }
            apiResponse.status = 400
    except Exception as e:
        error_trace = traceback.format_exc()
        logging.info(f'GET metadata failed. error :: {e}. error_trace :: {error_trace}')
        apiResponse.status = 500
        apiResponse.message = ERR_MSG.UNKNOWN

    return ordered_jsonify(apiResponse)

def get_additional_claims(id, name, email):
    additional_claims = {
        'id': str(id),
        'name': name,
        'email': email
    }

    return additional_claims

# GET endpoint
@app.route('/login', methods=['POST'])
def login():
    print('login ...')
    user_cred = request.get_json()
    username = user_cred.get("username")
    password = user_cred.get("password")
    id = 1
    additional_claims = get_additional_claims(id, username, username)
    access_token = create_access_token(identity=id, additional_claims=additional_claims)
    #setattr(_gptUser, 'access_token', access_token)
    print(f'access_token : {access_token}')
    login_res =  {
        'access_token' : access_token,
        'name' : 'Ajay Kumar',
        'email' : 'ajay@test.ccom'
    }
    return jsonify(login_res), 200

@app.route('/update_report', methods=['POST'])
def update_report():
    req_body = request.get_json()

    reportUtil = ReportUtils(report_file)
    reportUtil.update_report(req_body)

    return jsonify({
        'status' : 'ok'
    }), 200


@app.route('/new_report', methods=['POST'])
def new_report_from_template():
    template_id = request.form.get('template_id')
    logging.info(f'creating new report ....')
    apiResponse = ApiResponse(200, 'ok', None)

    report_title = request.form.get('report_title')
    lp_cms_id = request.form.get('lp_cms_id')
    train_no = request.form.get('train_no')
    load = request.form.get('load')
    bmbs = request.form.get('bmbs')
    loco_no = request.form.get('loco_no')
    spm = request.form.get('spm')
    goods = request.form.get('goods')

    logging.info(f'is goods :: {goods}')
    other_params = {
        'lp_cms_id': lp_cms_id,
        'train_no': train_no,
        'load': load,
        'bmbs': bmbs,
        'loco_no': loco_no,
        'spm': spm,
        'goods': goods
    }

    logging.info(f'creating new report. other_params : {other_params}')
    speedo_file = None
    station_file = None
    isd_file = None
    psr_file = None
    tsr_file = None
    gradient_file = None
    attacking_speed_file = None

    try :
        if template_id == None:
            apiResponse.status = 400
            apiResponse.message = ERR_MSG.MISSING_TEMPLATE_ID
        else :
            with open(template_file, "r", encoding="utf-8-sig") as file:
                template_data = json.load(file)
        logging.info(f'template_data ::  {template_data}, template_id :: {template_id}')
        templates = template_data["templates"]
        logging.info(f'templates ::  {templates}')
        #template = next((template for template in templates if template["id"] == template_id), None)
        template = None
        for one_template in templates :
            #logging.info(f'one_template ::  {one_template}, one_template["id"] :: {one_template["id"]}, template_id dtype :: {type(template_id)}, one_template["id"] dtype :: {one_template["id"]}')
            if one_template["id"] == int(template_id) :
                template = one_template
                break

        logging.info(f'selected template {template}')
        speedo_files = request.files.getlist("speedo_file")
        if len(speedo_files) > 0:
            speedo_file = speedo_files[0]

        tsr_files = request.files.getlist("tsr_file")
        if len(tsr_files) > 0:
            tsr_file = tsr_files[0]


        station_file = template.get("station_file")
        isd_file = template.get("isd_file")
        gradient_file = template.get("gradient_file")
        attacking_speed_file = template.get("attacking_speed_file")
        psr_file = template.get("psr_file")

        all_files = {
            'speedo_file': speedo_file,
            'station_file': station_file,
            'isd_file': isd_file,
            'psr_file': psr_file,
            'tsr_file': tsr_file,
            'gradient_file': gradient_file,
            'attacking_speed_file': attacking_speed_file,
            'report_file': report_file
        }

        logging.info(f'creating new report. all_files : {all_files}')

        railDataService = RailDataService(report_title, all_files, other_params)
        apiResponse.data = railDataService.prepare()
    except Exception as e:
        error_trace = traceback.format_exc()
        logging.info(f'add report failed. error :: {e}. error_trace :: {error_trace}')
        apiResponse.status = 500
        apiResponse.message = ERR_MSG.UNKNOWN

    return jsonify(apiResponse.__dict__)

@app.route('/new_report_v2', methods=['POST'])
def new_report():
    report_title = request.form.get('report_title')
    lp_cms_id = request.form.get('lp_cms_id')
    train_no = request.form.get('train_no')
    load = request.form.get('load')
    bmbs = request.form.get('bmbs')
    loco_no = request.form.get('loco_no')
    spm = request.form.get('spm')

    other_params = {
        'lp_cms_id' : lp_cms_id,
        'train_no' : train_no,
        'load' : load,
        'bmbs' : bmbs,
        'loco_no' : loco_no,
        'spm' : spm
    }

    template_id = request.form.get('template_id')
    if template_id == None :
        pass

    stations_id = request.form.get('stations_id')
    isd_id = request.form.get('isd_id')

    speedo_file = None
    station_file = None
    isd_file = None
    psr_file = None
    tsr_file = None
    gradient_file = None
    attacking_speed_file = None

    if stations_id == None :
        station_files = request.files.getlist("station_file")
        if len(station_files) > 0:
            station_file = station_files[0]

    if isd_id == None :
        isd_files = request.files.getlist("isd_file")
        if len(isd_files) > 0:
            isd_file = isd_files[0]

    psr_id = request.form.get('psr_id')
    if psr_id == None:
        psr_files = request.files.getlist("psr_file")
        if len(psr_files) > 0:
            psr_file = psr_files[0]

    tsr_id = request.form.get('tsr_id')
    if tsr_id == None:
        tsr_files = request.files.getlist("tsr_file")
        if len(tsr_files) > 0:
            tsr_file = tsr_files[0]

    gradient_id = request.form.get('gradient_id')
    if gradient_id == None:
        gradient_files = request.files.getlist("gradient_file")
        if len(gradient_files) > 0:
            gradient_file = gradient_files[0]

    attacking_speed_files = request.files.getlist("attacking_speed_file")
    if len(attacking_speed_files) > 0:
        attacking_speed_file = attacking_speed_files[0]

    speedo_files = request.files.getlist("speedo_file")
    if len(speedo_files) > 0:
        speedo_file = speedo_files[0]

    if speedo_file == None:
        return jsonify({
            'reason' : 'missing speedo file'
        }), 400

    with open(template_file, "r", encoding="utf-8-sig") as file:
        template_data = json.load(file)

    templates = template_data['templates']

    max_id = max(int(t["id"]) for t in templates) if templates else 0

    new_report = {
        'id' : max_id + 1
    }
    templates.append(new_report)

    json_to_save = {
       'templates' :  templates
    }

    with open(template_file, 'w') as f:
        json.dump(json_to_save, f, indent=4)
    #self, speed_file, psr_file, tsr_file, gradient_file

    all_files = {
        'speedo_file' : speedo_file,
        'station_file' : station_file,
        'isd_file' : isd_file,
        'psr_file' : psr_file,
        'tsr_file' : tsr_file,
        'gradient_file' : gradient_file,
        'attacking_speed_file': attacking_speed_file,
        'report_file' : report_file
    }
    railDataService = RailDataService(report_title, all_files, other_params)
    #railDtataPrep = RailDataPrep(report_title, speedo_file, station_file, isd_file, psr_file, tsr_file, gradient_file, report_file)

    prep_response = {}
    try:
        prep_response = railDataService.prepare()
    except Exception as e:
        error_trace = traceback.format_exc()
        logging.info(f'add report failed. error :: {e}. error_trace :: {error_trace}')
        prep_response = {
            'error' : str(e)
        }

    return jsonify(prep_response), 200

@app.route('/stat', methods=['GET'])
def stat():
    report_id = request.args.get('id')

    with open(report_file, "r", encoding="utf-8-sig") as file:
        report_json = json.load(file)

    metadata_json = next((report for report in report_json["reports"] if report["id"] == report_id), None)

    file_path = metadata_json.get("data_file")
    station_file = metadata_json.get("station_file")
    station_df = pd.read_csv(station_file)
    from_station = station_df.iloc[0]['station']
    to_station = station_df.iloc[-1]['station']
    df = pd.read_csv(file_path)
    print(f'data len {len(df)}')
    avg_speed = round(df.loc[:, 'speed'].mean(), 2)
    max_speed = int(df.loc[:, 'speed'].max())
    print(f'avg_speed {avg_speed}, max_speed : {max_speed}')


    df['datetime'] = pd.to_datetime(df['date'] + ' ' + df['time'], format=RailConst.dt_time_format)
    df['time'] = pd.to_datetime(df['time'], format='%H:%M:%S').dt.time
    time_diff = (pd.to_datetime(df['datetime'].iloc[-1], format=RailConst.dt_time_format) -
                 pd.to_datetime(df['datetime'].iloc[0], format=RailConst.dt_time_format))
    print(f'time_diff : {time_diff}')
    # Extract hours, minutes, and seconds
    hours, remainder = divmod(time_diff.total_seconds(), 3600)
    minutes, seconds = divmod(remainder, 60)

    # Format output
    formatted_time_diff = f"{int(hours)}h {int(minutes)}m {int(seconds)}s"
    total_distance = float(round(df['total_distance'].iloc[-1] / 1000, 4))

    departure_time = pd.to_datetime(df['datetime'].iloc[0], format=RailConst.dt_time_format)
    departure_time_str = str(departure_time).split()[-1]

    arrival_time = pd.to_datetime(df['datetime'].iloc[-1], format=RailConst.dt_time_format)
    arrival_time_str = str(arrival_time).split()[-1]

    current_time = datetime.now()

    # Format as 'DD/MM/YYYY HH:MM'
    formatted_time = current_time.strftime('%d/%m/%Y %H:%M')

    stat_data = {
        'loco_no': '31405',
        'from': from_station,
        'to': to_station,
        'departure_time' : departure_time,
        'arrival_time': arrival_time,
        'avg_speed' : avg_speed,
        'max_speed' : max_speed,
        'max_speed_5' : 'na',
        'running_time' : formatted_time_diff,
        'total_distance' : total_distance,
        'analyzed_by': 'some-name',
        'date_of_analysis': formatted_time,
        'date_of_working' : '19/03/2025 18:36',
        'train_num': 'NSFTIAFAS',
        'load' : '141=2357 T',
        'bmbs' : 0,
        'SPM' : 'Laxven'
    }

    return jsonify(stat_data), 200

# add speed restriction
def add_sr(df, fig, sr_type, sr_color, txt_padding):
    sr_section = f'{sr_type}_section'
    sr_from = f'{sr_type}_from'
    sr_to = f'{sr_type}_to'
    sr_speed = f'{sr_type}_speed'

    if not sr_section in df.columns:
        return

    psr_dfs = {section: group for section, group in df.groupby(sr_section)}

    for psr_section in psr_dfs:
        _df = psr_dfs[psr_section]
        # print(_df)

        # Add PSR Speed as horizontal red lines
        for _, row in _df.iterrows():
            psr_mid_time = row["time"]  # Middle time for label
            fig.add_trace(go.Scatter(
                x=[psr_mid_time - pd.Timedelta(seconds=5), psr_mid_time + pd.Timedelta(seconds=5)],
                # Define a short horizontal range
                y=[row[sr_speed], row[sr_speed]],  # Keep Y the same for a horizontal line
                mode="lines",
                line=dict(color=sr_color, width=2),  # Customize line color and thickness
                showlegend=False
            ))

        label_text = f"{sr_type} {int(row[sr_speed])}"
        fig.add_trace(go.Scatter(
            x=[psr_mid_time],
            y=[row[sr_speed] + txt_padding],
            text=[label_text],
            mode="text",
            line=dict(color=sr_color),
            textfont=dict(size=10, family="Arial", weight="normal"),
            textposition="middle center",
            showlegend=False
        ))

@app.route('/get_station')
def get_station():
    report_id = request.args.get('id')

    with open(report_file, "r", encoding="utf-8-sig") as file:
        report_json = json.load(file)

    metadata_json = next((report for report in report_json["reports"] if report["id"] == report_id), None)
    file_path = metadata_json.get("station_file")

    df = pd.read_csv(file_path)
    json_data = df.to_json(orient='records')

    return json_data


from utils.report_utils import ReportUtils
@app.route('/report')
def report():
    report_id = request.args.get('id')
    logging.info(f'report ...report_id : {report_id}')


    with open(report_file, "r", encoding="utf-8-sig") as file:
        report_json = json.load(file)
    one_report = next((report for report in report_json["reports"] if report["id"] == report_id), None)

    #title = one_report.get("title")

    from_station = request.args.get('from_station')
    to_station = request.args.get('to_station')
    speed_time_fig = generate_speed_time_chart(report_id, from_station, to_station)
    _speed_time_img_fname = f"{report_id}_speed_time.png"
    pio.write_image(speed_time_fig, _speed_time_img_fname)

    speed_before_fig = speed_before_halt(report_id, from_station, to_station)
    _speed_before_halt_img_fname = f"{report_id}_speed_before_halt.png"
    pio.write_image(speed_before_fig, _speed_before_halt_img_fname)

    df = stat_speed_before_halt(report_id, from_station, to_station)

    reportUtil = ReportUtils(report_file)
    report = reportUtil.generate_report_doc(one_report, _speed_time_img_fname, _speed_before_halt_img_fname, df)

    return send_file(report, as_attachment=True)

@app.route('/chart_speed_time')
def chart_speed_time_json():
    logging.info(f'chart_speed_time_json ...')
    report_id = request.args.get('id')

    from_station = request.args.get('from_station')
    to_station = request.args.get('to_station')
    fig = generate_speed_time_chart(report_id, from_station, to_station)
    chart_json = pio.to_json(fig)

    return jsonify(chart_json)

@app.route('/chart_speed_time_img')
def chart_speed_time_img():
    logging.info(f'chart_speed_time_json ...')
    report_id = request.args.get('id')
    from_station = request.args.get('from_station')
    to_station = request.args.get('to_station')
    fig = generate_speed_time_chart(report_id, from_station, to_station)
    _img_fname = f"{report_id}_speed_time.png"
    pio.write_image(fig, _img_fname)
    return send_file(_img_fname, as_attachment=True)

def generate_speed_time_chart(report_id, from_station, to_station):
    logging.info(f'generate_speed_time_chart : id : {report_id}')

    with open(report_file, "r", encoding="utf-8-sig") as file:
        report_json = json.load(file)

    metadata_json = next((report for report in report_json["reports"] if report["id"] == report_id), None)

    file_path = metadata_json.get("data_file")

    df = pd.read_csv(file_path)

    if from_station and to_station:
        from_index = df[df['station'] == from_station].index.min()
        to_index = df[df['station'] == to_station].index.min()
        print(f'generate_chart :: from_index : {from_index}, to_index : {to_index}')
        if not pd.notna(from_index):
            from_index = 0
        if not pd.notna(to_index):
            to_index = df.index[-1]
        print(f'final index generate_chart :: from_index : {from_index}, to_index : {to_index}')
        df = df.loc[from_index:to_index]

    # Convert date and time columns to a proper datetime format
    #2025-03-19 21:36:27
    df["time"] = pd.to_datetime(df["date_time"], format="%Y-%m-%d %H:%M:%S")

    # Filter only rows where PSR data is available
    #psr_df = df.dropna(subset=["psr_from", "psr_to", "psr_speed"])

    # Define tick values
    num_ticks = 20  # Number of ticks for x-axis
    tick_indices = np.linspace(0, len(df['time']) - 1, num_ticks, dtype=int)
    tick_values = df['time'].iloc[tick_indices]

    # Create figure
    fig = go.Figure()

    # Add Speed line plot (Primary Y-Axis)

    fig.add_trace(go.Scatter(
        x=df["time"],
        y=df["speed"],
        mode="lines",
        name="Speed",
        line=dict(color="gray"),
        showlegend=False,
        hoverinfo='text',
        hovertext=df["hovertext"]
    ))

    psr_type = 'psr'
    psr_color = 'red'
    psr_txt_padding = 3
    add_sr(df, fig, psr_type, psr_color, psr_txt_padding)

    tsr_type = 'tsr'
    tsr_color = 'black'
    tsr_txt_padding = -3
    add_sr(df, fig, tsr_type, tsr_color, tsr_txt_padding)

    if 'station' in df.columns:
        # Add station names as annotations
        for i, row in df.dropna(subset=['station']).iterrows():
            fig.add_annotation(
                x=row['time'],
                y= -8,
                text=row['station'],
                showarrow=False,
                arrowhead=2,
                ax=0,
                ay=-40,
                textangle=-70,
                font=dict(color="red", size=12, family="Arial")
            )

    if 'isd_signal' in df.columns:
        # Add ISD names as annotations
        for i, row in df.dropna(subset=['isd_signal']).iterrows():
            fig.add_annotation(
                x=row['time'],
                y=125,
                text=row['isd_signal'],
                showarrow=True,
                arrowhead=2,
                ax=0,
                ay=-40,
                textangle=-90,
                font=dict(color="black", size=8, family="Arial")
            )

    if 'gradient_block_section' in df.columns:
        df_filtered = df.dropna(subset=['gradient_block_section'])
        fig.add_trace(go.Scatter(
            x=df_filtered["time"],
            y=df_filtered["speed"] + 1,
            mode="markers",
            marker=dict(
                symbol="asterisk-open",  # Use 'asterisk-open' instead of '*'
                color="orange",
                size=3,  # Adjust size as needed
            ),
            name="Gradient",
            hoverinfo="skip"  # Optional: Hide hover tooltip for markers
        ))

    if 'attacking_speed_required' in df.columns:
        df_filtered = df.dropna(subset=['attacking_speed_required'])
        fig.add_trace(go.Scatter(
            x=df_filtered["time"],
            y=df_filtered["speed"],
            mode="markers",
            marker=dict(
                symbol="star",  # Use 'asterisk-open' instead of '*'
                color="red",
                size=10,  # Adjust size as needed
            ),
            name="Attacking",
            hoverinfo="skip"  # Optional: Hide hover tooltip for markers
        ))


    # fig.update_traces(hoverinfo="x+y", line=dict(width=1, color="red"))
    # Customize layout
    fig.update_layout(
        title="Time vs Speed with PSR Speed Sections",
        xaxis_title="Time",
        yaxis_title="Speed (km/h)",
        xaxis=dict(
            tickformat="%H:%M:%S",
            tickangle=-70,
            tickmode="array",
            tickvals=tick_values,
            ticktext=tick_values.dt.strftime("%H:%M:%S")
        ),
        hoverlabel=dict(bgcolor="gray"),
        width=1900,
        height=800
    )
    return fig
    #chart_json = pio.to_json(fig)

    #return jsonify(chart_json)
@app.route('/speed_before_halt_img')
def speed_before_halt_img():
    report_id = request.args.get('id')
    from_station = request.args.get('from_station')
    to_station = request.args.get('to_station')
    fig = speed_before_halt(report_id, from_station, to_station)
    chart_json = pio.to_json(fig)
    _img_fname = f"{report_id}_speed_before_halt.png"
    pio.write_image(fig, _img_fname)
    return send_file(_img_fname, as_attachment=True)

@app.route('/speed_before_halt')
def speed_before_halt():
    report_id = request.args.get('id')
    from_station = request.args.get('from_station')
    to_station = request.args.get('to_station')
    fig = speed_before_halt(report_id, from_station, to_station)
    chart_json = pio.to_json(fig)

    return jsonify(chart_json)

def speed_before_halt(report_id, from_station, to_station):
    with open(report_file, "r", encoding="utf-8-sig") as file:
        report_json = json.load(file)
    #print(f'report_json : {report_json}')
    metadata_json = next((report for report in report_json["reports"] if report["id"] == report_id), None)

    file_path = metadata_json.get("speed_before_1000m")
    #print(f'file_path : {file_path}')
    df = pd.read_csv(file_path)
    #print(f'df len : {len(df)}')

    if from_station and to_station:
        from_index = df[df['station'] == from_station].index.min()
        to_index = df[df['station'] == to_station].index.min()

        if not pd.notna(from_index):
            from_index = 0
        if not pd.notna(to_index):
            to_index = df.index[-1]

        df = df.loc[from_index:to_index]

    # Define the x-axis labels
    x_labels = ['1000m', '500m', '400m', '200m', '100m', 'halt']

    # Create a figure
    fig = go.Figure()

    # Add traces for each station with classification
    for index, row in df.iterrows():
        speeds = [row['1000m'], row['500m'], row['400m'], row['200m'], row['100m'], row['halt']]
        #remark = classify_speed_drop(speeds)  # Determine smooth or abrupt
        fig.add_trace(go.Scatter(
            x=x_labels,
            y=speeds,
            mode='lines+markers',
            name=f"{row['halt_name']} ({row['remark']})",  # Append remark to station name
            line=dict(shape='spline')
        ))

    # Update layout
    fig.update_layout(
        title="Speed Before Halt with Remarks",
        xaxis=dict(title="Distance Before Halt"),
        yaxis=dict(title="Speed (km/h)"),
        showlegend=True,
        height=800,
        width=1600
    )

    return fig

def find_nearest_index(df, target_distance):
    idx = (np.abs(df["total_distance"] - target_distance)).idxmin()
    return idx

def stat_speed_before_halt(report_id, from_station, to_station):
    with open(report_file, "r", encoding="utf-8-sig") as file:
        report_json = json.load(file)
    #print(f'report_json : {report_json}')
    metadata_json = next((report for report in report_json["reports"] if report["id"] == report_id), None)

    file_path = metadata_json.get("speed_before_1000m")

    df = pd.read_csv(file_path)

    if from_station and to_station:
        from_index = df[df['station'] == from_station].index.min()
        to_index = df[df['station'] == to_station].index.min()
        print(f'stat_speed_before_halt from_station : {from_station}, from_index : {from_index}, to_station : {to_station}, to_index : {to_index}')

        if not pd.notna(from_index):
            from_index = 0
        if not pd.notna(to_index):
            to_index = df.index[-1]
        df = df.loc[from_index:to_index]
    #json_data = df.to_json(orient='records')  # Converts to list of dicts

    return df

@app.route('/stat_speed_before_halt')
def api_stat_speed_before_halt():
    report_id = request.args.get('id')
    from_station = request.args.get('from_station')
    to_station = request.args.get('to_station')
    df = stat_speed_before_halt(report_id, from_station, to_station)
    json_data = df.to_json(orient='records')
    return json_data



# For local running
if __name__ == "__main__":
    app.run(debug=True, host='0.0.0.0', port=5010)