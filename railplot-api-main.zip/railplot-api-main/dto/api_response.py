import json
class ApiResponse:
    def __init__(self, status, message, data):
        self.status = status
        self.message = message
        self.data = data
    def __str__(self):
        return json.dumps(self.__dict__)

    def to_dict(self):
        return {
            "status": self.status,
            "message": self.message,
            "data" : self.data.to_dict()
        }