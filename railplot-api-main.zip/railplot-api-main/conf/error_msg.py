class ERR_MSG:
    UNKNOWN_LOGIN_SRC = 'Invalid login source'
    UNKNOWN = 'Unexpected error.'
    MISSING_TEMPLATE_ID = 'Missing template id.'

