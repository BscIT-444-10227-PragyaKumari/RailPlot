class RailConst:

    dt_time_format = '%d/%m/%y %H:%M:%S'

    time_format = '%H:%M:%S'
    dt_format = '%d/%m/%y'

    DATA_DIR = 'data'
    REPORT_FILE = 'data/report.json'
    NO_DATA_DIR = 'no_data'

    SPEEDO_SRC_LAXVEN = 'Laxven'

    SPEEDO_SRC_TELPRO = 'Telpro'
    SPEEDO_DT_FMT_TELPRO = '%d/%m/%Y'
    SPEEDO_TM_FMT_TELPRO = '%H:%M:%S'

    SPEEDO_SRC_RAIL_TECH = 'RailTech'
    SPEEDO_DT_FMT_RAIL_TECH = '%d/%m/%Y'
    SPEEDO_TM_FMT_RAIL_TECH = '%H:%M:%S'

    SPEEDO_SRC_MEDHA = 'Medha'
    SPEEDO_DT_FMT_MEDHA = '%d/%m/%y'
    SPEEDO_TM_FMT_MEDHA = '%H:%M:%S'


