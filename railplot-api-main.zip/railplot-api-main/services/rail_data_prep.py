import pandas as pd
import re
import numpy as np
import os
import logging

from utils.report_utils import ReportUtils
from conf.const import RailConst
from utils.file_conversion_util import RailFileConvertor

temp_dir = 'data/temp'
out_dir = 'data'
no_data_dir = 'no_data'
station_distance_tolerance = 100
required_speedo_columns = {'date', 'time', 'speed', 'distance'}
required_station_columns = {'station', 'km'}

crew_file = 'data/crew.csv'
crew_df = pd.read_csv(crew_file)

class RailDataService :
    #def __init__(self, report_title, speed_file, station_file, isd_file, psr_file, tsr_file, gradient_file, report_file):
    def __init__(self, report_title, all_files, other_params):
        print(f'RailDataPrep ... {all_files}')
        self.report_title = report_title
        self.other_params = other_params
        self.lp_cms_id = other_params['lp_cms_id']
        self.train_no = other_params['train_no']
        self.load = other_params['load']
        self.bmbs = other_params['bmbs']
        self.loco_no = other_params['loco_no']
        self.spm = other_params['spm']

        self.report_file = all_files['report_file']
        self.speedo_file = all_files['speedo_file']
        self.station_file = all_files['station_file']
        self.isd_file = all_files['isd_file']
        self.psr_file = all_files['psr_file']
        self.tsr_file = all_files['tsr_file']
        self.gradient_file = all_files['gradient_file']
        self.attacking_speed_file = all_files['attacking_speed_file']


    def prep_speedo_data(self, speedo_df):
        logging.info(f'prep_speedo_data ...')
        speedo_df = speedo_df.dropna(subset=['time'])
        speedo_df['time'] = pd.to_datetime(speedo_df['time'], errors='coerce').dt.strftime('%H:%M:%S')

        speedo_df = speedo_df.dropna(subset=['date'])
        speedo_df["date_time"] = pd.to_datetime(speedo_df["date"] + " " + speedo_df["time"], format=RailConst.dt_time_format)
        is_cumulative_distance = (speedo_df['distance'].diff().fillna(0) >= 0).all()
        logging.info(f'is_cumulative_distance : {is_cumulative_distance}')
        if is_cumulative_distance:
            speedo_df['distance'] = (speedo_df['distance'] - speedo_df['distance'].shift(1)) * 1000

        speedo_df['total_distance'] = speedo_df['distance'].cumsum()
        speedo_df = speedo_df[['date', 'time', 'date_time', 'speed', 'distance', 'total_distance']]

        return speedo_df

    def add_distance_from_base_station(self, station_df):
        logging.info(f'add_distance_from_base_station ...')
        station_df['distance_from_base_stn_in_mtr'] = abs(((station_df['km'] - station_df['km'].iloc[0]) * 1000).astype(int))
        return station_df

    def find_nearest_row_id(self, speedo_df, dist: int) -> int:
        all_idx = (speedo_df['total_distance'] - dist).abs()
        # print(all_idx)
        nearest_idx = all_idx.idxmin()
        return nearest_idx

    def add_attacking_distance(self, speedo_df, attacking_distance_df):
        logging.info(f'add_attacking_distance ...')
        base_station_dist = speedo_df.iloc[0]['station_ref_distance'] * 1000
        total_rows = len(speedo_df)
        for ad_idx, ad_row in attacking_distance_df.iterrows():
            ad_distance = abs(int(ad_row['attacking_distance'] * 1000) - base_station_dist)
            attacking_speed_required = ad_row['attacking_speed_required']
            ad_distance_idx = self.find_nearest_row_id(speedo_df, ad_distance)

            if total_rows > ad_distance_idx :
                # find average speed at the moment
                speed_at_moment = speedo_df.loc[ad_distance_idx]['speed']
                # consider 3 seconds to calculate average speed
                """
                m = ad_distance_idx
                n = ad_distance_idx + 30
                speed_at_moment = round(speedo_df.loc[m:n, 'speed'].mean(), 2)
                """
                if speed_at_moment < attacking_speed_required :
                    speedo_df.loc[ad_distance_idx, 'attacking_speed_violation'] = f"Achieved Speed: {speed_at_moment} Kmph, Req: {attacking_speed_required} Kmph"

                add_extra = total_rows - ad_distance_idx
                if add_extra > 10 :
                    add_extra = 10
                for i in range(0, add_extra):
                    speedo_df.loc[ad_distance_idx + i, 'attacking_speed_required'] = ad_row['attacking_speed_required']
                    speedo_df.loc[ad_distance_idx + i, 'attacking_gradient'] = ad_row['attacking_gradient']

        return speedo_df

    def add_sr(self, speedo_df, psr_df, sr_type):
        logging.info(f'add_sr ... sr_type : {sr_type}')
        #logging.info(f'speedo_df.iloc[0] : {speedo_df.iloc[0]}')
        #logging.info(f'psr_df col : {psr_df.columns}')
        #speedo_df.to_csv('logs/temp_speedo.csv', index=False)
        #psr_df.to_csv('logs/temp_psr.csv', index=False)
        base_station_dist = speedo_df.iloc[0]['station_ref_distance'] * 1000

        logging.info(f'base_station_dist : {base_station_dist}, speedo_df.columns : {speedo_df.columns}' )

        sr_section = f'{sr_type}_section'
        sr_from = f'{sr_type}_from'
        sr_to = f'{sr_type}_to'
        sr_speed = f'{sr_type}_speed'
        sr_violation = f'{sr_type}_violation'

        speedo_df[sr_from] = pd.Series(dtype='Int64')
        speedo_df[sr_to] = pd.Series(dtype='Int64')
        speedo_df[sr_speed] = pd.Series(dtype='Int64')

        for psr_idx, psr_row in psr_df.iterrows():
            psr_section = psr_row[sr_section]
            logging.info(f'psr_row[sr_from] : {psr_row[sr_from]}, psr_row[sr_to] : {psr_row[sr_to]}')
            psr_from = abs(int(psr_row[sr_from] * 1000) - base_station_dist)
            psr_from_idx = self.find_nearest_row_id(speedo_df, psr_from)

            psr_to = abs(int(psr_row[sr_to] * 1000) - base_station_dist)
            psr_to_idx = self.find_nearest_row_id(speedo_df, psr_to)

            #logging.info(f'psr_section : {psr_section}, psr_from : {psr_from}, psr_from_idx : {psr_from_idx}, psr_to : {psr_to}, psr_to_idx : {psr_to_idx}')
            if psr_from_idx > psr_to_idx:
                _psr_from_idx = psr_to_idx
                psr_to_idx = psr_from_idx
                psr_from_idx = _psr_from_idx

            for i in range(psr_from_idx, psr_to_idx):
                # print(f'updating idx : {i}')
                speedo_df.loc[i, sr_section] = psr_row[sr_section]
                speedo_df.loc[i, sr_from] = abs(int(psr_row[sr_from] * 1000) - base_station_dist)
                speedo_df.loc[i, sr_to] = abs(int(psr_row[sr_to] * 1000) - base_station_dist)
                speedo_df.loc[i, sr_speed] = int(psr_row[sr_speed])

                _speed = speedo_df.iloc[i]['speed']
                _speed_restriction = int(psr_row[sr_speed])
                if (_speed > _speed_restriction):
                    #logging.info(f'== SR violation ==')
                    speedo_df.loc[i, sr_violation] = f'{psr_row[sr_section]}({_speed_restriction})'


            """
            filtered_speed = speedo_df.iloc[psr_from_idx:psr_to_idx]['speed']
            logging.info(f'filtered_speed :: {filtered_speed.head()}')
            if (filtered_speed > psr_row[sr_speed]).any():
                logging.info(f'No SR violation')  
            else:
                logging.info(f'SR violation')
            """


        logging.info(f'add_sr .. done ...')
        return speedo_df

    def add_isd(self, speedo_df, isd_df):
        logging.info(f'add_isd ...')
        isd_sum = 0
        for isd_idx, isd_row in isd_df.iterrows():
            isd = isd_row['isd']
            isd_section = isd_row['section']
            isd_signal = isd_row['signal']
            #logging.info(f'isd : {isd},isd tye : {type(isd)}, isd_section : {isd_section}, isd_signal : {isd_signal}')
            isd_sum = isd_sum + isd

            isd_to_idx = self.find_nearest_row_id(speedo_df, isd_sum)
            #print(f'isd : {isd}, isd_section : {isd_section}, isd_to_idx : {isd_to_idx}, isd_sum : {isd_sum}')
            speedo_df.loc[isd_to_idx, 'isd_section'] = isd_section
            speedo_df.loc[isd_to_idx, 'isd_signal'] = isd_signal
            speedo_df.loc[isd_to_idx, 'isd'] = isd_sum

        return speedo_df

    def add_station(self, stg1_speedo_df, station_df_stg1):
        logging.info(f'add_station ...')
        last_stn_found = False
        new_stn_df = pd.DataFrame(columns=stg1_speedo_df.columns)
        stg1_speedo_df.loc[stg1_speedo_df.index[0], "station"] = station_df_stg1.iloc[0]['station']
        stg1_speedo_df.at[stg1_speedo_df.index[0], 'station_ref_distance'] = station_df_stg1.iloc[0]['km']

        for index, row in station_df_stg1.iterrows():
            # print(f"Row {index}: station = {row['station']}, km = {row['km']}")
            stn_found = False
            last_stn_found = False
            for index2, row2 in stg1_speedo_df.iterrows():
                if abs(row['distance_from_base_stn_in_mtr'] - row2['total_distance']) < station_distance_tolerance : #and row2['speed'] == 0:
                    # print(f"adding stn : {row['Stations']}")
                    # speedo_df[index2]['STN'] = row['Stations']
                    stg1_speedo_df.at[index2, 'station'] = row['station']
                    stg1_speedo_df.at[index2, 'station_ref_distance'] = row['km']
                    stn_found = True
                    last_stn_found = True

                    new_stn_df.loc[len(new_stn_df)] = row

                    break

            #logging.info(f'{row['station']} stn_found : {stn_found}')

        """
        if last_stn_found == False:
            logging.info(f'Marking last station ...')
            stg1_speedo_df.loc[stg1_speedo_df.index[-1], "station"] = station_df_stg1.iloc[-1]['station']
            stg1_speedo_df.at[stg1_speedo_df.index[-1], 'station_ref_distance'] = station_df_stg1.iloc[-1]['km']
        """

        return stg1_speedo_df

    def add_halt(self, speedo_df):
        logging.info(f'add_halt ...')
        waiting_for_restart = False
        halt_idx = 0
        speedo_df['speed'] = pd.to_numeric(speedo_df['speed'], errors='coerce')
        for speedo_idx in range(1, len(speedo_df)):
            current_speed = speedo_df.loc[speedo_idx , 'speed']
            prev_speed = speedo_df.loc[speedo_idx - 1, 'speed']
            #logging.info(f'adding halt ..  current_speed : {current_speed}, prev_speed : {prev_speed}')
            if not waiting_for_restart:
                if current_speed == 0:
                    #logging.info(f'adding halt at {speedo_idx}')
                    speedo_df.at[speedo_idx, 'halt'] = f'Halt {halt_idx + 1}'
                    halt_idx = halt_idx +1
                    waiting_for_restart = True
            else:
                # Waiting for a restart; ignore speeds <= 10
                if current_speed > 10:
                    waiting_for_restart = False

        return speedo_df

    def verify_input_data_file(self, input_df, req_columns,  input_file_type) :
        logging.info(f'verify_input_data_file : {input_file_type}')
        if not req_columns.issubset(input_df.columns):
            missing = req_columns - set(input_df.columns)
            raise Exception(f'{input_file_type} missing require column : {missing}')

    def create_breaking_profile(self, speedo_df):
        logging.info(f'create_breaking_profile ...')
        distance_dict = {
            '1000m': 1000,
            '500m': 500,
            '400m': 400,
            '300m': 300,
            '200m': 200,
            '100m': 100,
            'halt': 0,
        }
        column_names = ['halt_name', 'halt_time']
        column_names.extend(distance_dict.keys())
        df_1000m = pd.DataFrame(columns=column_names)
        row_idx = 0
        for index, row in speedo_df.iterrows():
            is_none = pd.isnull(row['halt'])

            ##fix_it index > 1000
            if not is_none and index > 120:
                df_1000m.at[row_idx, 'halt_name'] = row['halt']
                df_1000m.at[row_idx, 'halt_time'] = row['time']
                total_distance = row['total_distance']
                # print(f'total_distance : {total_distance} ')

                for index2, key in enumerate(distance_dict):
                    value = distance_dict[key]
                    if key == 'halt' :
                        df_1000m.at[row_idx, key] = 0
                    else:
                        dist_x_m = total_distance - value
                        idx_x_m = self.find_nearest_row_id(speedo_df, dist_x_m)
                        df_1000m.at[row_idx, key] = speedo_df.at[idx_x_m, 'speed']

                row_idx = row_idx + 1

        braking_stages = ["1000m", "500m", "400m", "300m", "200m", "100m", "halt"]

        # Function to determine braking style
        def check_braking_style(row):
            #logging.info(f'check_braking_style ...')
            speeds = row[braking_stages].values  # Get speed values as a list
            speed_diffs = np.diff(speeds)  # Calculate speed differences

            # If any speed difference is positive (i.e., sudden increase), it's abrupt
            if np.any(speed_diffs > 0):
                return "abrupt"
            return "smooth"

        # Apply function to each row
        df_1000m["remark"] = df_1000m.apply(check_braking_style, axis=1)

        return df_1000m

    def add_gradient(self, speedo_df, gradient_df):
        logging.info(f'add_gradient ...')
        gradient_block_section_col_name = 'gradient_block_section'
        gradient_from_col_name = 'gradient_from'
        gradient_to_col_name = 'gradient_to'
        gradient_patch_km_col_name = 'gradient_patch_km'
        gradient_col_name = 'gradient'
        #if os.path.exists(gradient_file):
        #gradient_df = pd.read_csv(gradient_file)
        base_station_dist = speedo_df.iloc[0]['station_ref_distance'] * 1000

        for grad_idx, grad_row in gradient_df.iterrows():
            block_section = grad_row[gradient_block_section_col_name]
            patch_km = grad_row[gradient_patch_km_col_name]
            gradient = grad_row[gradient_col_name]

            gradient_from = abs(int(grad_row[gradient_from_col_name] * 1000) - base_station_dist)
            grad_from_idx = self.find_nearest_row_id(speedo_df, gradient_from)

            gradient_to = abs(int(grad_row[gradient_to_col_name] * 1000) - base_station_dist)
            grad_to_idx = self.find_nearest_row_id(speedo_df, gradient_to)

            if grad_from_idx > grad_to_idx:
                _grad_from_idx = grad_to_idx
                grad_to_idx = grad_from_idx
                grad_from_idx = _grad_from_idx

            for i in range(grad_from_idx, grad_to_idx):
                # print(f'updating idx : {i}')
                speedo_df.loc[i, gradient_block_section_col_name] = grad_row[gradient_block_section_col_name]
                speedo_df.loc[i, gradient_from_col_name] = abs(
                    int(grad_row[gradient_from_col_name] * 1000) - base_station_dist)
                speedo_df.loc[i, gradient_to_col_name] = abs(
                    int(grad_row[gradient_to_col_name] * 1000) - base_station_dist)
                speedo_df.loc[i, gradient_patch_km_col_name] = int(grad_row[gradient_patch_km_col_name])
                speedo_df.loc[i, gradient_col_name] = grad_row[gradient_col_name]

                    # print(f'updating idx : {i} done')

        """
        else:
            speedo_df[gradient_block_section_col_name] = ''
            speedo_df[gradient_from_col_name] = ''
            speedo_df[gradient_to_col_name] = ''
            speedo_df[gradient_patch_km_col_name] = ''
            speedo_df[gradient_col_name] = ''

        print(f'Saving file ...')
        speedo_df.to_csv(out_file, index=False)
        """

        return speedo_df

    def add_hover_text(self, speedo_df):
        logging.info(f'add_hover_text ...')
        speedo_df["hovertext"] = speedo_df.apply(
            lambda row: f"Time: {row.get('time')}<br>Speed: {row.get('speed')} km/h"
                        + (f"<br>PSR Section: {row.get('psr_section')}" if pd.notna(row.get('psr_section')) else "")
                        + (f"<br>PSR Speed: {row.get('psr_speed')}" if pd.notna(row.get('psr_speed')) else "")
                        + (f"<br>TSR Section: {row.get('tsr_section')}" if pd.notna(row.get('tsr_section')) else "")
                        + (f"<br>TSR Speed: {row.get('tsr_speed')}" if pd.notna(row.get('tsr_speed')) else "")
                        + (f"<br>PSR Violation: {row.get('psr_violation')}" if pd.notna(row.get('psr_violation')) else "")
                        + (f"<br>TSR Violation: {row.get('tsr_violation')}" if pd.notna(row.get('tsr_violation')) else "")
                        + (f"<br>Gradient Block: {row.get('gradient_block_section')}" if pd.notna(row.get('gradient_block_section')) else "")
                        + (f"<br>Gradient: {row.get('gradient')}" if pd.notna(row.get('gradient')) else "")
                        + (f"<br>Attacking Speed: {row.get('attacking_speed_required')}" if pd.notna(row.get('attacking_speed_required')) else "")
                        + (f"<br>Attacking Gradient: {row.get('attacking_gradient')}" if pd.notna(row.get('attacking_gradient')) else ""),
            axis=1
        )

        return speedo_df

    def get_ideal_max_speed_time(self, speedo_df, max_speed):
        logging.info(f'get_ideal_max_speed_time ...')
        # Calculate threshold speed (Max Speed - 5 km/h)
        threshold_speed = max_speed - 5

        # Filter rows where speed >= threshold
        high_speed_df = speedo_df[speedo_df['speed'] >= threshold_speed]

        # Count how many seconds meet the condition (assuming each row is 1 second apart)
        time_seconds = len(high_speed_df)
        # Convert seconds to hours, minutes, and seconds
        hours = time_seconds // 3600
        minutes = (time_seconds % 3600) // 60
        seconds = time_seconds % 60

        # Format the time string
        return f"{hours}H {minutes}M {seconds}S"

    def att_speed_violation(self, speedo_df):
        logging.info(f'adding att_speed_violation ...')
        violation_report = []
        violation = 'attacking_speed_violation'
        if violation in speedo_df.columns:
            speedo_dfv = speedo_df[[violation, 'date', 'time']]
            unique_violations = speedo_df[violation].unique()
            logging.info(f'unique_violations :: {unique_violations}')
            for unique_violation in unique_violations:
                filtered_df = speedo_dfv[speedo_dfv[violation] == unique_violation]
                logging.info(f'filtered_df len :: {len(filtered_df)}')
                if len(filtered_df) > 0:
                    at_time = f"{filtered_df.iloc[0]['date']} {filtered_df.iloc[0]['time']}"
                    violation_report.append({
                            'time' : at_time,
                            'violation' : unique_violation
                        }
                    )

        return violation_report

    def sr_violation(self, speedo_df, sr_type):
        logging.info(f'adding sr_violation .. sr_type {sr_type}')
        violation_report = []
        violation = f'{sr_type}_violation'
        section = f'{sr_type}_section'
        if violation in speedo_df.columns:
            speedo_dfv = speedo_df[[violation, 'date', 'time']]
            unique_violations = speedo_df[violation].unique()

            for unique_violation in unique_violations:
                filtered_df = speedo_dfv[speedo_dfv[violation] == unique_violation]
                logging.info(f'sr_violation .. filtered_df len : {len(filtered_df)}')
                if len(filtered_df) > 0 :
                    _from = f"{filtered_df.iloc[0]['date']} {filtered_df.iloc[0]['time']}"
                    _to = f"{filtered_df.iloc[-1]['date']} {filtered_df.iloc[-1]['time']}"
                    violation_report.append({
                        section : unique_violation,
                        'from' : _from,
                        'to' : _to
                    })

        return violation_report

    def prepare(self):
        logging.info('preparing report ...')
        reportUtil = ReportUtils(self.report_file)

        last_report_id = reportUtil.get_report_last_id() + 1
        #next_id = str(last_report_id + 1)
        spm_source = self.other_params.get('spm')
        #goods = self.other_params.get('goods')
        goods = str(self.other_params.get('goods')).lower() == 'true'
        logging.info(f'goods : {goods}, goods == True :: {goods == True}')
        railFileConvertor = RailFileConvertor(spm_source, self.speedo_file, last_report_id)
        speedo_df = railFileConvertor.get_rail_data()
        #speedo_df = pd.read_csv(self.speedo_file)
        #required_columns = {'date', 'time', 'speed', 'distance'}
        prep_resp = {}
        self.verify_input_data_file(speedo_df, required_speedo_columns, 'speedo')

        logging.info(f'speedo_df len : {len(speedo_df)}')
        # speedo_df.replace(r'^\s*$', pd.NA, regex=True, inplace=True)
        # speedo_df = speedo_df.dropna(how='all')
        speedo_df.replace(r'^\s*$', pd.NA, regex=True, inplace=True)

        # Drop rows where 'date', 'time', or 'distance' is missing
        speedo_df = speedo_df.dropna(subset=['date', 'time', 'distance'])
        speedo_df = speedo_df.dropna(how='all')

        speedo_df = self.prep_speedo_data(speedo_df)
        logging.info(f'speedo_df 10 rows before halt :: {speedo_df.head()}')

        speedo_df = self.add_halt(speedo_df)
        #logging.info(f'speedo_df 10 rows after halt :: {speedo_df.head()}')
        sr_type_psr  ='psr'
        sr_type_tsr = 'tsr'
        if self.station_file != None :
            station_df = pd.read_csv(self.station_file)
            logging.info(f'station_df 10 rows :: {station_df.head()}')
            self.verify_input_data_file(station_df, required_station_columns,'station')
            station_df = self.add_distance_from_base_station(station_df)
            speedo_df = self.add_station(speedo_df, station_df)

        if self.station_file != None and self.isd_file != None:
            isd_df = pd.read_csv(self.isd_file)
            #isd_df = isd_df[pd.to_numeric(isd_df['signal'], errors='coerce').notna()]
            #isd_df['signal'] = pd.to_numeric(isd_df['signal'], errors='coerce')
            isd_df = isd_df[pd.to_numeric(isd_df['isd'], errors='coerce').notna()]
            speedo_df = self.add_isd(speedo_df, isd_df)
        logging.info(f'adding psr ...')
        if self.station_file != None and self.psr_file != None:
            logging.info(f'adding psr ...')
            psr_df = pd.read_csv(self.psr_file)
            speedo_df = self.add_sr(speedo_df, psr_df, sr_type_psr)
            logging.info(f'adding psr ... done')

        if self.station_file != None and self.tsr_file != None:
            logging.info(f'adding tsr ...')
            tsr_df = pd.read_csv(self.tsr_file)
            speedo_df = self.add_sr(speedo_df, tsr_df, sr_type_tsr)
            logging.info(f'adding tsr ... done')

        if self.station_file != None and self.gradient_file != None:
            logging.info(f'adding gradient ...')
            gradient_df = pd.read_csv(self.gradient_file)
            speedo_df = self.add_gradient(speedo_df, gradient_df)
            logging.info(f'adding gradient ... done')

        if self.station_file != None and self.attacking_speed_file != None and goods == True:
            logging.info(f'adding attacking_speed_file ...')
            attacking_speed_df = pd.read_csv(self.attacking_speed_file)
            speedo_df = self.add_attacking_distance(speedo_df, attacking_speed_df)
            logging.info(f'adding attacking_speed_file ... done')

        logging.info(f'adding hover ...')
        speedo_df = self.add_hover_text(speedo_df)
        #speedo_df.to_csv('logs/temp_speedo.csv', index=False)
        logging.info(f'adding hover ... done')
        #logging.info(f'speedo_df head :: {speedo_df.head()}')

        out_data_dir = f'{out_dir}/{last_report_id}'
        os.makedirs(out_data_dir, exist_ok=True)

        speedo_data_file = f'{out_data_dir}/speedo.csv'

        station_data_file = f'{no_data_dir}/stations.csv'
        if self.station_file != None:
            station_data_file = f'{out_data_dir}/stations.csv'
            station_df.to_csv(station_data_file, index=False)

        breaking_profile_data_file = ''
        if self.station_file != None:
            breaking_profile_data_file = f'{out_data_dir}/breaking_profile.csv'
            breaking_df = self.create_breaking_profile(speedo_df)

            breaking_df.to_csv(breaking_profile_data_file, index=False)

        speedo_df.to_csv(speedo_data_file, index=False)

        analyzed_by = ''
        stn_from = ''
        stn_to = ''

        if self.station_file != None:
            stn_from = station_df.iloc[0]['station']
            stn_to = station_df.iloc[-1]['station']


        max_speed = int(speedo_df.loc[:, 'speed'].max())

        max_speed_5 = self.get_ideal_max_speed_time(speedo_df, max_speed)

        speedo_df['datetime'] = pd.to_datetime(speedo_df['date'] + ' ' + speedo_df['time'], format=RailConst.dt_time_format)

        departure_time = pd.to_datetime(speedo_df['datetime'].iloc[0], format=RailConst.dt_time_format)
        departure_time_str = speedo_df['datetime'].iloc[0].strftime(RailConst.dt_time_format)
        #departure_time_str = str(departure_time).split()[-1]
        arrival_time = pd.to_datetime(speedo_df['datetime'].iloc[-1], format=RailConst.dt_time_format)

        #logging.info('last 10 rows ....')
        #logging.info(speedo_df.tail(10))
        arrival_time_str = speedo_df['datetime'].iloc[-1].strftime(RailConst.dt_time_format)
        #arrival_time_str = str(arrival_time).split()[-1]

        time_diff = (pd.to_datetime(speedo_df['datetime'].iloc[-1], format=RailConst.dt_time_format) -
                     pd.to_datetime(speedo_df['datetime'].iloc[0], format=RailConst.dt_time_format))
        print(f'time_diff : {time_diff}')
        # Extract hours, minutes, and seconds
        hours, remainder = divmod(time_diff.total_seconds(), 3600)
        minutes, seconds = divmod(remainder, 60)

        # Format output
        formatted_time_diff = f"{int(hours)}h {int(minutes)}m {int(seconds)}s"
        total_distance = float(round(speedo_df['total_distance'].iloc[-1] / 1000, 4))
        logging.info(f'calculating avg speed :: total_distance : {total_distance}, hours : {hours}, minutes : {minutes}, seconds : {seconds}')
        #avg_speed = round(speedo_df.loc[:, 'speed'].mean(), 2)
        total_hr = hours + minutes / 60 + seconds / 3600
        avg_speed = round(total_distance / total_hr, 2)

        psr_violation_list = self.sr_violation(speedo_df, sr_type_psr)
        tsr_violation_list = self.sr_violation(speedo_df, sr_type_tsr)

        attacking_speed_list = self.att_speed_violation(speedo_df)

        stat = {
            'avg_speed' : avg_speed,
            'max_speed' : max_speed,
            'max_speed_5' : max_speed_5,
            'departure_time': departure_time_str,
            'arrival_time': arrival_time_str,
            'running_time': formatted_time_diff,
            'total_distance': total_distance,
            'psr_violation' : psr_violation_list,
            'tsr_violation': tsr_violation_list,
            'attacking_speed_violation' : attacking_speed_list
        }

        if self.lp_cms_id :
            crew_rows = crew_df[crew_df['cms_id'] == self.lp_cms_id]

            crew_details = {}
            print(f'crew row : {crew_rows}')
            if not crew_rows.empty:
                crew_row = crew_rows.iloc[0]  #
                self.other_params['nominated_cli'] = crew_row['crew_nli']
                self.other_params['crew_name'] = crew_row['crew_name']
                self.other_params['crew_designation'] = crew_row['crew_designation']

        speedo_df.to_csv('logs/temp_speedo.csv', index=False)

        reportUtil.append_report(self.report_title, analyzed_by, stn_from, stn_to, speedo_data_file, station_data_file, breaking_profile_data_file, self.other_params, stat)
        return prep_resp

    def update_report(self, report_param):
        reportUtil = ReportUtils(self.report_file)
        lp_cms_id = report_param.get("lp_cms_id")

        if lp_cms_id :
            crew_rows = crew_df[crew_df['cms_id'] == lp_cms_id]
            if not crew_rows.empty:
                crew_row = crew_rows.iloc[0]
                report_param['nominated_cli'] = crew_row['crew_nli']
                report_param['crew_name'] = crew_row['crew_name']
                report_param['crew_designation'] = crew_row['crew_designation']

        reportUtil.update_report(report_param)

    def generate_report_file(self, report_param):
        pass


