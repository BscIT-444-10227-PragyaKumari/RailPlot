<!--
title: 'Serverless Framework Python Flask API backed by DynamoDB on AWS'
description: 'This template demonstrates how to develop and deploy a simple Python Flask API service backed by DynamoDB running on AWS Lambda using the Serverless Framework.'
layout: Doc
framework: v4
platform: AWS
language: Python
priority: 2
authorLink: 'https://github.com/serverless'
authorName: 'Serverless, Inc.'
authorAvatar: 'https://avatars1.githubusercontent.com/u/13742415?s=200&v=4'
-->

# Serverless Framework Python Flask API service backed by DynamoDB on AWS

This template demonstrates how to develop and deploy a simple Python Flask API service, backed by DynamoDB, running on AWS Lambda using the Serverless Framework.

This template configures a single function, `api`, which is responsible for handling all incoming requests thanks to configured `http` events. To learn more about `http` event configuration options, please refer to [http event docs](https://www.serverless.com/framework/docs/providers/aws/events/apigateway/). As the events are configured in a way to accept all incoming requests, `Flask` framework is responsible for routing and handling requests internally. The implementation takes advantage of `serverless-wsgi`, which allows you to wrap WSGI applications such as Flask apps. To learn more about `serverless-wsgi`, please refer to corresponding [GitHub repository](https://github.com/logandk/serverless-wsgi). The template also relies on `serverless-python-requirements` plugin for packaging dependencies from `requirements.txt` file. For more details about `serverless-python-requirements` configuration, please refer to corresponding [GitHub repository](https://github.com/UnitedIncome/serverless-python-requirements).

Additionally, the template also handles provisioning of a DynamoDB database that is used for storing data about users. The Flask application exposes two endpoints, `POST /users` and `GET /user/{userId}`, which allow to create and retrieve users.

## Usage

### Prerequisites

In order to package your dependencies locally with `serverless-python-requirements`, you need to have `Python3.8` installed locally. You can create and activate a dedicated virtual environment with the following command:

```
python3 -m venv ./venv
source ./venv/bin/activate
pip install -r requirements.txt
```
```
deactivate
rm -rf ./venv
```

Alternatively, you can also use `dockerizePip` configuration from `serverless-python-requirements`. For details on that, please refer to corresponding [GitHub repository](https://github.com/UnitedIncome/serverless-python-requirements).

### Deployment

install dependencies with:

rm -rf core_layer

mkdir -p core_layer/python
pip install -r core_requirements.txt --platform manylinux2014_x86_64 --target=core_layer/python --implementation cp --python-version 3.11 --only-binary=:all:
cd core_layer
zip -r ../core_layer.zip python

rm -rf ext_layer
rm ext_layer.zip

mkdir -p ext_layer/python
pip install --platform manylinux2014_x86_64 --target=ext_layer/python --implementation cp --python-version 3.11 --only-binary=:all: numpy==2.2.4
pip install -r ext_requirements.txt --platform manylinux2014_x86_64 --target=ext_layer/python --implementation cp --python-version 3.11 --only-binary=:all:

cd ext_layer

find python -name "*.pyc" -delete
find python -name "__pycache__" -type d -exec rm -rf {} +
find python -name "tests" -type d -exec rm -rf {} +
find python -name "docs" -type d -exec rm -rf {} +

zip -r ../ext_layer.zip python



rm -rf chart_layer
rm chart_layer.zip

mkdir -p chart_layer/python
pip install -r chart_requirements.txt --platform manylinux2014_x86_64 --target=chart_layer/python --implementation cp --python-version 3.11 --only-binary=:all:
cd chart_layer

find python -name "*.pyc" -delete
find python -name "__pycache__" -type d -exec rm -rf {} +
find python -name "tests" -type d -exec rm -rf {} +
find python -name "docs" -type d -exec rm -rf {} +

zip -r ../chart_layer.zip python

```
npm install
```
unzip -l chart_layer.zip | awk '{sum+=$1} END {print sum / 1024 / 1024, "MB"}'

unzip -l core_layer.zip | awk '{sum+=$1} END {print sum / 1024 / 1024, "MB"}'
unzip -l ext_layer.zip | awk '{sum+=$1} END {print sum / 1024 / 1024, "MB"}'
unzip -l chart_layer.zip | awk '{sum+=$1} END {print sum / 1024 / 1024, "MB"}'


and then perform deployment with:

```
serverless deploy
```

After running deploy, you should see output similar to:

```
Deploying "aws-python-flask-dynamodb-api" to stage "dev" (us-east-1)

Using Python specified in "runtime": python3.12

Packaging Python WSGI handler...

✔ Service deployed to stack aws-python-flask-dynamodb-api-dev (123s)

endpoints:
  ANY - https://xxxxxxxxxx.execute-api.us-east-1.amazonaws.com/dev/
  ANY - https://xxxxxxxxxx.execute-api.us-east-1.amazonaws.com/dev/{proxy+}
functions:
  api: aws-python-flask-dynamodb-api-dev-api (41 MB)
```

_Note_: In current form, after deployment, your API is public and can be invoked by anyone. For production deployments, you might want to configure an authorizer. For details on how to do that, refer to [http event docs](https://www.serverless.com/framework/docs/providers/aws/events/http-api).

### Invocation

After successful deployment, you can create a new user by calling the corresponding endpoint:

```
curl --request POST 'https://xxxxxx.execute-api.us-east-1.amazonaws.com/dev/users' --header 'Content-Type: application/json' --data-raw '{"name": "John", "userId": "someUserId"}'
```

Which should result in the following response:

```json
{ "userId": "someUserId", "name": "John" }
```

You can later retrieve the user by `userId` by calling the following endpoint:

```
curl https://xxxxxxx.execute-api.us-east-1.amazonaws.com/dev/users/someUserId
```

Which should result in the following response:

```json
{ "userId": "someUserId", "name": "John" }
```

### Local development

Thanks to capabilities of `serverless-wsgi`, it is also possible to run your application locally, however, in order to do that, you will need to first install `werkzeug`, `boto3` dependencies, as well as all other dependencies listed in `requirements.txt`. It is recommended to use a dedicated virtual environment for that purpose. You can install all needed dependencies with the following commands:

```
pip install werkzeug boto3
pip install -r requirements.txt
```

Additionally, you will need to emulate DynamoDB locally, which can be done by using `serverless-dynamodb-local` plugin. In order to do that, execute the following commands:

```
serverless plugin install -n serverless-dynamodb-local
serverless dynamodb install
```

It will add the plugin to `devDependencies` in `package.json` file as well as to `plugins` section in `serverless.yml`. Additionally, it will also install DynamoDB locally.

You should also add the following config to `custom` section in `serverless.yml`:

```yml
custom:
  (...)
  dynamodb:
    start:
      migrate: true
    stages:
      - dev
```

Additionally, we need to reconfigure DynamoDB Client to connect to our local instance of DynamoDB. We can take advantage of `IS_OFFLINE` environment variable set by `serverless-wsgi` plugin and replace:

```python
dynamodb_client = boto3.client('dynamodb')
```

with

```python
dynamodb_client = boto3.client('dynamodb')

if os.environ.get('IS_OFFLINE'):
    dynamodb_client = boto3.client('dynamodb', region_name='localhost', endpoint_url='http://localhost:8000')
```

Now you can start DynamoDB local with the following command:

```
serverless dynamodb start
```

At this point, you can run your application locally with the following command:

```
serverless wsgi serve
```

For additional local development capabilities of `serverless-wsgi` and `serverless-dynamodb-local` plugins, please refer to corresponding GitHub repositories:

- https://github.com/logandk/serverless-wsgi
- https://github.com/99x/serverless-dynamodb-local
