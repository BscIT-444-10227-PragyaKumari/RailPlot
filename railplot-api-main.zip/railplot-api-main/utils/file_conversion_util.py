import subprocess

import os
import pandas as pd

from conf.const import RailConst
import logging
import uuid

backup_dir = f'{RailConst.DATA_DIR}/back/'

class RailFileConvertor:
    def __init__(self, data_source, data_file, report_id):
        self.data_source = data_source
        self.data_file = data_file
        self.report_id = report_id

    def take_backup(self):
        original_file_name = self.data_file.filename
        bak_dir = f'{RailConst.DATA_DIR}/bak'
        self.data_file.save(os.path.join(bak_dir, original_file_name))

    def get_rail_data(self):
        logging.info(f'get_rail_data ... data_source : { self.data_source}, data_file : {self.data_file}, report_id : {self.report_id}')
        # take backup
        original_file_name = self.data_file.filename
        random_uuid = uuid.uuid4()
        original_file = f'{random_uuid}_{original_file_name}'
        self.data_file.save(os.path.join(backup_dir, original_file))
        full_path = backup_dir + original_file
        df = None
        if self.data_source == RailConst.SPEEDO_SRC_LAXVEN:
            logging.info(f'loading df ...')
            df = pd.read_csv(full_path, skiprows=6, usecols=[0, 1, 2], header=None,
                             names=["datetime", "distance", "speed"], sep='\t')
            logging.info(f'speedo_df len stg 1 : {len(df)}')
            df = df.iloc[:-1]
            df['datetime'] = pd.to_datetime(df['datetime'].str.strip(), format=RailConst.dt_time_format)

            df['date'] = df['datetime'].dt.strftime(RailConst.dt_format)
            df['time'] = df['datetime'].dt.strftime(RailConst.time_format)
            temp_file_cleaned = f'{RailConst.DATA_DIR}/back/{random_uuid}_cleaned.csv'
            df.to_csv(temp_file_cleaned, index=False)
            df = pd.read_csv(temp_file_cleaned)
        elif self.data_source == RailConst.SPEEDO_SRC_RAIL_TECH:
            cleaned_lines = None
            with open(full_path, 'r', encoding='ISO-8859-1') as infile:
                lines = infile.readlines()
                # Remove first 10 lines
                cleaned_lines = lines[12:]
                # Save to a new file
            temp_file = f'{RailConst.DATA_DIR}/back/{random_uuid}_2_{original_file_name}'
            with open(temp_file, 'w', encoding='ISO-8859-1') as outfile:
                outfile.writelines(cleaned_lines)

            df = pd.read_csv(temp_file,
                             usecols=[0, 1, 2, 3],
                             on_bad_lines='skip')
            # Rename columns
            df = df.rename(columns={
                'Date (dd-mm-yy)': 'date',
                'Time (HH:mm:ss)': 'time',
                'Inst. Distance (Km)': 'distance',
                'Inst. Speed (Km/h)': 'speed'
            })

            logging.info(f'dataframe loaded ....')
            df['date'] = pd.to_datetime(df['date'].str.strip(), format=RailConst.SPEEDO_DT_FMT_RAIL_TECH, errors='coerce')
            df['time'] = pd.to_datetime(df['time'].str.strip(), format=RailConst.SPEEDO_TM_FMT_RAIL_TECH, errors='coerce').dt.time
            df['date'] = df['date'].dt.strftime(RailConst.dt_format)
            df['time'] = df['time'].apply(lambda t: t.strftime(RailConst.time_format) if pd.notnull(t) else None)

            df = df.dropna(subset=['date'])

            # Optional: Reset index after dropping rows
            df = df.reset_index(drop=True)

            temp_file_cleaned = f'{RailConst.DATA_DIR}/back/{random_uuid}_cleaned.csv'
            df.to_csv(temp_file_cleaned, index=False)
            df = pd.read_csv(temp_file_cleaned)
        elif self.data_source == RailConst.SPEEDO_SRC_MEDHA:
            cleaned_lines = None
            with open(full_path, 'r', encoding='ISO-8859-1') as infile:
                lines = infile.readlines()
                cleaned_lines = lines[14:]
            temp_file = f'{RailConst.DATA_DIR}/back/{random_uuid}_2_{original_file_name}'
            with open(temp_file, 'w', encoding='ISO-8859-1') as outfile:
                outfile.writelines(cleaned_lines)

            df = pd.read_csv(temp_file, sep='|',
                             header=None,
                             usecols=[0, 1, 2, 3],  # Only load columns at index 0, 1, 2, 3
                             names=['date', 'time', 'speed', 'distance'])

            logging.info(f'dataframe loaded ....')
            df['date'] = pd.to_datetime(df['date'].str.strip(), format=RailConst.SPEEDO_DT_FMT_MEDHA, errors='coerce')
            df['time'] = pd.to_datetime(df['time'].str.strip(), format=RailConst.SPEEDO_TM_FMT_MEDHA, errors='coerce').dt.time
            df['date'] = df['date'].dt.strftime(RailConst.dt_format)
            df['time'] = df['time'].apply(lambda t: t.strftime(RailConst.time_format) if pd.notnull(t) else None)

            df = df.dropna(subset=['date'])

            # Optional: Reset index after dropping rows
            df = df.reset_index(drop=True)
            temp_file_cleaned = f'{RailConst.DATA_DIR}/back/{random_uuid}_cleaned.csv'
            df.to_csv(temp_file_cleaned, index=False)
            df = pd.read_csv(temp_file_cleaned)
        elif self.data_source == RailConst.SPEEDO_SRC_TELPRO:
            logging.info('converting {full_path} to csv.')

            xls = pd.ExcelFile(full_path)
            df = pd.read_excel(xls, sheet_name="Sheet1", skiprows=28, usecols=[1, 6, 12, 18],names=["date", "time", "distance", "speed"])
            df.iloc[:, 2] = df.iloc[:, 2].shift(1)  # Shift column 2 (index 1)
            df.iloc[:, 3] = df.iloc[:, 3].shift(1)  # Shift column 3 (index 2)
            df['date'] = pd.to_datetime(df['date'].str.strip(), format=RailConst.SPEEDO_DT_FMT_TELPRO, errors='coerce')
            df['date'] = pd.to_datetime(df['date']).dt.strftime(RailConst.dt_format)
            df = df[df['date'].notna() & (df['date'] != '')]

            df = df[df['distance'].notna() & (df['distance'] != '')]
            df['distance'] = df['distance'].astype(int)

            df = df[df['speed'].notna() & (df['speed'] != '')]
            df['speed'] = df['speed'].astype(int)

            temp_file_cleaned = f'{RailConst.DATA_DIR}/back/{random_uuid}_cleaned.csv'
            df.to_csv(temp_file_cleaned, index=False)
            df = pd.read_csv(temp_file_cleaned)

        logging.info(f'df :: {df.columns}')
        return df

    def to_csv(self, input_file, output_dir):
        subprocess.run(["soffice", "--headless", "--convert-to", 'csv', input_file, "--outdir", output_dir])

