import json
import logging
from datetime import datetime
import pandas as pd
from docxtpl import DocxTemplate, InlineImage
from docx.shared import Mm
from docx.shared import Inches, Pt
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

from conf.const import  RailConst
crew_file = 'data/crew.csv'
crew_df = pd.read_csv(crew_file)

class ReportUtils:
    def __init__(self, report_file):
        self.report_file = report_file

    def get_report(self):
        report_data = {}
        with open(self.report_file, "r", encoding="utf-8-sig") as file:
            report_data = json.load(file)

        return report_data

    def get_report_last_id(self):
        logging.info('get_report_last_id ...')
        report_data = self.get_report()

        reports = report_data['reports']
        max_id = max(int(r["id"]) for r in reports) if reports else 0
        logging.info(f'get_report_last_id max_id : {max_id}')
        return max_id


    def append_report(self, report_title, analyzed_by, stn_from, stn_to, data_file, station_file, speed_before_1000m, other_params, stat):
        report_data = self.get_report()
        last_report_id = self.get_report_last_id()
        next_id = str(last_report_id + 1)
        print(f'stat :: {stat}')

        #'date_of_analysis': formatted_time,
        #'date_of_working': '19/03/2025 18:36',
        now = datetime.now()
        date_of_analysis = now.strftime('%d/%m/%Y %H:%M')
        new_report = {
            'id' : next_id,
            'title': report_title,
            'analyzed_by': analyzed_by,
            'stn_from': stn_from,
            'stn_to': stn_to,
            'lp_cms_id' : other_params.get('lp_cms_id'),
            'crew_name': other_params.get('crew_name'),
            'nominated_cli': other_params.get('nominated_cli'),
            'crew_designation': other_params.get('crew_designation'),
            'train_id': other_params.get('train_no'),
            'load': other_params.get('load'),
            'bmbs': other_params.get('bmbs'),
            'loco_no': other_params.get('loco_no'),
            'spm': other_params.get('spm'),
            'avg_speed': stat.get('avg_speed'),
            'max_speed': stat.get('max_speed'),
            'max_speed_5': stat.get('max_speed_5'),
            'date_of_working': stat.get('departure_time'),
            'date_of_analysis': date_of_analysis,
            'departure_time': stat.get('departure_time'),
            'arrival_time': stat.get('arrival_time'),
            'running_time': stat.get('running_time'),
            'total_distance': stat.get('total_distance'),
            'psr_violation': stat.get('psr_violation'),
            'tsr_violation': stat.get('tsr_violation'),
            'attacking_speed_violation': stat.get('attacking_speed_violation'),
            'deficiency': '',
            'remark': '',
            'data_file': data_file,
            'station_file': station_file,
            'speed_before_1000m': speed_before_1000m
        }

        reports = report_data['reports']

        reports.insert(0, new_report)

        final_reports_to_save = {
            'reports': reports
        }

        with open(self.report_file, 'w') as f:
            json.dump(final_reports_to_save, f, indent=4)

    def update_report(self, report_param):
        report_data = self.get_report()
        report_id = report_param['id']
        logging.info(f'update_report ... report_id : {report_id}')
        for report in report_data["reports"]:
            if report["id"] == report_id:
                report["analyzed_by"] = report_param.get("analyzed_by")
                report["train_id"] = report_param.get("train_id")
                report["load"] = report_param.get("load")
                report["bmbs"] = report_param.get("bmbs")
                report["loco_no"] = report_param.get("loco_no")
                report["spm"] = report_param.get("spm")
                report["deficiency"] = report_param.get("deficiency")
                report["remark"] = report_param.get("remark")

                lp_cms_id = report_param.get("lp_cms_id")
                logging.info(f'update_report ... lp_cms_id : {lp_cms_id}')
                report["lp_cms_id"] = lp_cms_id
                if lp_cms_id:
                    crew_rows = crew_df[crew_df['cms_id'] == lp_cms_id]
                    if not crew_rows.empty:
                        crew_row = crew_rows.iloc[0]
                        report['nominated_cli'] = crew_row['crew_nli']
                        report['crew_name'] = crew_row['crew_name']
                        report['crew_designation'] = crew_row['crew_designation']

                break
        with open(self.report_file, 'w') as f:
            json.dump(report_data, f, indent=4)

    """
    def create_word_table_from_df(self, document, df):
        table = document.add_table(rows=1, cols=len(df.columns))
        table.style = 'Table Grid'

        # Add header
        hdr_cells = table.rows[0].cells
        for i, column_name in enumerate(df.columns):
            hdr_cells[i].text = str(column_name)

        # Add rows
        for index, row in df.iterrows():
            row_cells = table.add_row().cells
            for i, cell in enumerate(row):
                row_cells[i].text = str(cell)

        return table
    """

    from docx.shared import Inches, Pt
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn

    def create_word_table_from_df(self, document, df, font_name="Abadi MT"):
        table = document.add_table(rows=1, cols=len(df.columns))
        table.style = 'Table Grid'

        col_widths = [Inches(1.5)] * len(df.columns)

        # === HEADER ROW ===
        hdr_cells = table.rows[0].cells
        for i, column_name in enumerate(df.columns):
            paragraph = hdr_cells[i].paragraphs[0]
            run = paragraph.add_run(str(column_name))
            run.font.name = font_name
            run._element.rPr.rFonts.set(qn('w:eastAsia'), font_name)
            run.font.bold = True
            run.font.size = Pt(9)

            # Header background color
            shading_elm = OxmlElement('w:shd')
            shading_elm.set(qn('w:fill'), 'D9D9D9')  # Light gray
            hdr_cells[i]._tc.get_or_add_tcPr().append(shading_elm)

            hdr_cells[i].width = col_widths[i]

        # === DATA ROWS ===
        for idx, row in df.iterrows():
            row_cells = table.add_row().cells
            for i, cell in enumerate(row):
                paragraph = row_cells[i].paragraphs[0]
                run = paragraph.add_run(str(cell))
                run.font.name = font_name
                run._element.rPr.rFonts.set(qn('w:eastAsia'), font_name)
                run.font.size = Pt(9)

                row_cells[i].width = col_widths[i]

                # Alternate row coloring: apply shading if row index is odd
                if idx % 2 == 1:
                    shading_elm = OxmlElement('w:shd')
                    shading_elm.set(qn('w:fill'), 'F2F2F2')  # Very light gray
                    row_cells[i]._tc.get_or_add_tcPr().append(shading_elm)

        return table

    def generate_report_doc(self, all_data, _speed_time_img_fname, _speed_before_halt_img_fname, stat_before_1000m_df):
        logging.info(f'generate_report_doc all_data :: {all_data}, stat_before_1000m :: {type(stat_before_1000m_df)}')
        doc_tpl = DocxTemplate('report_templates/report_template.docx')
        subdoc = doc_tpl.new_subdoc()
        self.create_word_table_from_df(subdoc, stat_before_1000m_df)
        report_id = all_data.get('id')
        all_data['speed_time_chart'] = InlineImage(doc_tpl, _speed_time_img_fname, width=Mm(190))
        all_data['speed_before_1000m'] = InlineImage(doc_tpl, _speed_before_halt_img_fname, width=Mm(190))
        all_data['items'] = subdoc
        doc_tpl.render(all_data)
        #logging.info(f"generating notice {out_file_name}. after render")
        out_dir = f'{RailConst.DATA_DIR}/{report_id}'
        out_file_name = f'{out_dir}/{report_id}_report.docx'

        logging.info(f"generating report {out_file_name}.")
        doc_tpl.save(out_file_name)

        return out_file_name

